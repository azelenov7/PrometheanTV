package tv.promethean.broadcast.steps;

import tv.promethean.broadcast.pages.HomePage;

import org.apache.http.auth.UsernamePasswordCredentials;
import org.openqa.selenium.security.Credentials;
import org.seleniumhq.jetty9.security.authentication.LoginAuthenticator;

import com.gargoylesoftware.htmlunit.javascript.host.Console;

import jline.internal.Log;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class ViewerSteps extends ScenarioSteps {
	
	private static final long serialVersionUID = -508402045095492650L;
	
	private HomePage homePage;
	
	@Step
	public void open_home_page() {
		homePage.open();
	}
	
	@Step
	public void click_on_the_signin_button() {
		
		Log.info(homePage.signinButton.getAttribute("ui-sref"));
		Log.info(homePage.signinButton.getAttribute("class"));
		//homePage.waitForAngularRequestsToFinish();
		
		Log.info(homePage.signinButton.isDisplayed());
		Log.info(homePage.signinButton.isCurrentlyVisible());
		Log.info(homePage.signinButton.getAttribute("href"));
		homePage.openAt("https://qa.broadcast.promethean.tv/authentication/signin");
	}
	
	@Step
	public void fill_in_incorrect_credentials() {
		homePage.usernameInput.sendKeys("TestUsername");
		homePage.passwordInput.sendKeys("TestPassword");
		homePage.confirmSignInButton.click();
		homePage.confirmSignInButton.click();
	}
	
	
}